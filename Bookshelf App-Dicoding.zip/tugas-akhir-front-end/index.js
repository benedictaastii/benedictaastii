let books = [];

document.addEventListener("DOMContentLoaded", () => {
  loadBooks();
  renderBooks();
  document.getElementById("form").addEventListener("submit", addBook);
  document.getElementById("searchForm").addEventListener("input", searchBooks);
  document.getElementById("btn-reset").addEventListener("click", clearBooks);
});

function addBook(event) {
  event.preventDefault();
  const title = document.getElementById("title").value;
  const author = document.getElementById("author").value;
  const year = document.getElementById("year").value;
  const isComplete = false;

  const newBook = {
    id: +new Date(),
    title,
    author,
    year,
    isComplete,
  };

  books.push(newBook);
  saveBooks();
  renderBooks();
  document.getElementById("form").reset();
}

function renderBooks() {
  const unreadBookList = document.getElementById("books");
  const readBookList = document.getElementById("books-items");

  unreadBookList.innerHTML = "";
  readBookList.innerHTML = "";

  for (const book of books) {
    const bookElement = makeBookElement(book);

    if (!book.isComplete) {
      unreadBookList.append(bookElement);
    } else {
      readBookList.append(bookElement);
    }
  }

  updateBookCount();
}

function makeBookElement(book) {
  const bookElement = document.createElement("div");
  bookElement.classList.add("item");
  bookElement.dataset.id = book.id;

  const innerElement = document.createElement("div");
  innerElement.classList.add("inner");

  const titleElement = document.createElement("h2");
  titleElement.innerText = book.title;

  const authorElement = document.createElement("p");
  authorElement.innerText = `Penulis: ${book.author}`;

  const yearElement = document.createElement("p");
  yearElement.innerText = `Tahun: ${book.year}`;

  const actionButtons = document.createElement("div");
  actionButtons.classList.add("action-buttons");

  const checkButton = document.createElement("button");
  checkButton.classList.add("check-button");
  checkButton.innerHTML = "✔";
  checkButton.addEventListener("click", () => {
    moveBook(book.id, true);
  });

  const undoButton = document.createElement("button");
  undoButton.classList.add("undo-button");
  undoButton.innerHTML = "↩";
  undoButton.addEventListener("click", () => {
    moveBook(book.id, false);
  });

  const trashButton = document.createElement("button");
  trashButton.classList.add("trash-button");
  trashButton.innerHTML = "🗑";
  trashButton.addEventListener("click", () => {
    removeBook(book.id);
  });

  actionButtons.append(checkButton, undoButton, trashButton);
  innerElement.append(titleElement, authorElement, yearElement);
  bookElement.append(innerElement, actionButtons);

  return bookElement;
}

function updateBookCount() {
  const unreadBookCount = books.filter((book) => !book.isComplete).length;
  const readBookCount = books.filter((book) => book.isComplete).length;

  document.getElementById("unread-book").innerText = unreadBookCount;
  document.getElementById("read-book").innerText = readBookCount;
  document.getElementById("total-books").innerText = books.length;
}

function moveBook(bookId, isComplete) {
  const book = books.find((book) => book.id === bookId);
  book.isComplete = isComplete;

  saveBooks();
  renderBooks();
}

function removeBook(bookId) {
  books = books.filter((book) => book.id !== bookId);

  saveBooks();
  renderBooks();
}

function clearBooks() {
  if (confirm("Apakah Anda yakin ingin menghapus semua buku?")) {
    books = [];
    saveBooks();
    renderBooks();
  }
}

function saveBooks() {
  localStorage.setItem("books", JSON.stringify(books));
}

function loadBooks() {
  const storedBooks = JSON.parse(localStorage.getItem("books"));
  if (storedBooks) {
    books = storedBooks;
  }
}

function searchBooks() {
  const searchText = document.getElementById("bookTitle").value.toLowerCase();
  const filteredBooks = books.filter((book) =>
    book.title.toLowerCase().includes(searchText)
  );

  const unreadBookList = document.getElementById("books");
  const readBookList = document.getElementById("books-items");

  unreadBookList.innerHTML = "";
  readBookList.innerHTML = "";

  for (const book of filteredBooks) {
    const bookElement = makeBookElement(book);

    if (!book.isComplete) {
      unreadBookList.append(bookElement);
    } else {
      readBookList.append(bookElement);
    }
  }
}
